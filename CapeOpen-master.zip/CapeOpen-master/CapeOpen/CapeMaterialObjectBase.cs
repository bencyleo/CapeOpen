﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CapeOpen
{
    //[Serializable]
    //[System.Runtime.InteropServices.ComVisible(true)]
    ////[System.Runtime.InteropServices.ComSourceInterfaces(typeof(ICapeThermoMaterialObjectCOM))]
    //[System.Runtime.InteropServices.ClassInterface(System.Runtime.InteropServices.ClassInterfaceType.None)]
    //public abstract class CapeMaterialObjectBase:
    //    CapeObjectBase,
    //    ICapeThermoMaterialObject,
    //    ICapeThermoMaterialObjectCOM
    //{
    //}
}
